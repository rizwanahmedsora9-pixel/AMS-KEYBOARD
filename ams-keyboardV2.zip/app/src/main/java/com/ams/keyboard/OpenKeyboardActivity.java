package com.ams.keyboard;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

/**
 * Transparent trampoline activity that forces AMS Keyboard to open on screen
 * even when no text field is present (Hacker's Keyboard mode).
 */
public class OpenKeyboardActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep activity transparent and pass touches through
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);

        // A dummy view to hold focus and soft input request
        View dummy = new View(this);
        dummy.setFocusable(true);
        dummy.setFocusableInTouchMode(true);
        setContentView(dummy);
        dummy.requestFocus();

        // 1. Summon directly through active IME service instance if running
        AmsKeyboardService service = AmsKeyboardService.getInstance();
        if (service != null) {
            service.requestShowSelf(0);
        }

        // 2. Summon through system InputMethodManager forced toggle
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
            imm.showSoftInput(dummy, InputMethodManager.SHOW_FORCED);
        }

        // Delay finish slightly so the keyboard window is created and stays on top of the underlying app
        new Handler(Looper.getMainLooper()).postDelayed(this::finish, 180);
    }
}
